Some utilities for reading, writing, and color-coding .flo images.

Written according to the c++ source code of Daniel Scharstein 

Deqing Sun, 11/03/07

see colorTest for visualizing the encoding scheme, reading and writing  .flo files.

