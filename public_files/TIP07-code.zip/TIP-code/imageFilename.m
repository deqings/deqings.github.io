function y = imageName(n)
% usage: y = imageFilename(n)
%
% return name of orignal images selected by n
%
% inputs: N 
% outputs: string of the image name

% written by Sun Deqing (22 May 2006)  
filename = {'lena_b_512_512.bmp', 'peppers_b_512_512.bmp', 'barbara_b_512_512.bmp', 'baboon_b_512_512.bmp', 'foreman00.tif', ...
            'flower.bmp', 'Model.bmp', 'girl.bmp', 'hill.bmp', 'butter.bmp', ...
        	'zelda.bmp', 'boat.bmp', 'plane.bmp', 'pens.bmp', 'yacht.bmp',...
            'board.bmp', 'airfield.bmp', 'couple.bmp', 'lax.bmp', 'irene.bmp',...
            'man.bmp', 'woman.bmp', 'fruits.bmp', 'head.bmp'};  
y   = filename{n};        