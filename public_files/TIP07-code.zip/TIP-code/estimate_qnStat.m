function qnStat  = estimate_qnStat(qnModel, qnInput)
% estimates the quantization noise statistics, according to different
% models
% 
%
% writtern by Sun Deqing (24/10/2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

switch qnModel
    case 'Robertson'     
        qChoice = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        
        Q = qtable(qChoice);
        Sigma_qc  = zeros(blockSize^2, blockSize^2);
        Sigma_q     = [];      
        t   = dctmtx(8);
        T   = kron(t,t);                            % perform 2D forward DCT to a vector of length blockSize^2 
                                                    % (vectorized represenation of an image block of size blockSize * blockSize)                                            
        for u = 1 : blockSize;                      % calculate DCT domain quantization noise covariance matrix  
            for v = 1 : blockSize;  
                 Sigma_qc( (v-1) * blockSize + u ,(v-1) * blockSize + u  )    = Q(u,v) * Q(u,v)/12;  
%                  if Q(u,v) == 255;
%                      factor = 0.001;        % add to check whehther larger variance for high freq truncated coe produces better PSNR
%                      Sigma_qc( (v-1) * blockSize + u ,(v-1) * blockSize + u  ) = factor * Sigma_qc( (v-1) * blockSize + u ,(v-1) * blockSize + u  );
%                  end;
            end;
        end;        
        Sigma_q = T' * Sigma_qc * T;      % transform back to spatial domain
        invSigma_q  = inv(Sigma_q);

        qnStat.Sigma_q  = Sigma_q;
        qnStat.invSigma_q  = invSigma_q;
    case 'ActualVariance'
        iImage      = qnInput.iImage;                                % Parameter Setting
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize; 
        I = double(imread( imageFilename(iImage) ));
        C   = blkproc(I , [blockSize blockSize], 'dct2');
        [I_q, C_q]  = code_BDCT(I, qChoice, blockSize);
        
        n_qc    = C_q - C;

        [height,width]      = size(I);
        
        Sigma_qc  = zeros(blockSize^2, blockSize^2);
        Sigma_q     = [];      
        t   = dctmtx(8);
        T   = kron(t,t);
        
        for u = 1 : blockSize; 
            for v = 1 : blockSize;
                for m = 1 : height/blockSize; 
                    for n = 1 : width/blockSize; 
                        n_qcUV(m,n) = n_qc((m-1)*blockSize + u, (n-1)*blockSize + v);
                    end;
                end;
                Sigma_qc( (v-1) * blockSize + u ,(v-1) * blockSize + u  )    = var(n_qcUV(:));
            end;
        end;

        Sigma_q = T' * Sigma_qc * T;      % transform back to spatial domain
        invSigma_q  = inv(Sigma_q);

        qnStat.Sigma_q  = Sigma_q;
        qnStat.invSigma_q  = invSigma_q;      
        
    case 'Truncation'
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        C_q         = qnInput.C_q;
        
        Q       = qtable(qChoice);
        tempVar = Q.^2 / 12;
        [height, width] = size(C_q);
        qnStat.Var      = repmat(tempVar, [height/blockSize, width/blockSize]);
        qnStat.CqZero   = C_q == 0;        

    case 'Truncation2'
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        C_q         = qnInput.C_q;
        
        Q       = qtable(qChoice);
        tempVar = Q.^2 / 12;
        [height, width] = size(C_q);

        CqZero  = (C_q ~= 0);   % The following program check whether Cq(u,v) is zero for all the blocks, if yes, gives a mark 1
        nonZero = zeros(blockSize, blockSize); 
        for m = 1 : height/blockSize
            for n = 1 : width/blockSize
                nonZero = nonZero + CqZero( (m-1)*blockSize+1 : m*blockSize, (n-1)*blockSize+1 : n*blockSize );
            end;
        end;
        truncation  = (nonZero ==0);              
        qnStat.Var  = repmat(tempVar, [height/blockSize, width/blockSize]);        
        qnStat.CqZero   = repmat(truncation, [height/blockSize, width/blockSize]);
    case 'Truncation3'
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        C_q         = qnInput.C_q;
        iImage      = qnInput.iImage;
        
        Q       = qtable(qChoice);
        tempVar = Q.^2 / 12;
        [height, width] = size(C_q);
        qnStat.Var      = repmat(tempVar, [height/blockSize, width/blockSize]);
        qnStat.CqZero   = C_q == 0;        

        % added to consider DC and low freq coefficients that are quantized
        % to zero
        C_std   = estimate_DCT_variance(iImage, blockSize);        
        mask = C_std < Q/5; % 3 -- 30.091 31.375(1.284) 31.375(1.284) 31.443(1.352) 5 --- 30.091 31.385(1.294) 31.385(1.294) 31.451(1.360)
        qnStat.CqZero = blkproc(qnStat.CqZero , [blockSize blockSize], 'P1 & x', mask);
        qnStat.CqZero = logical(qnStat.CqZero);
    case 'Generalized_Gauss'
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        C_q         = qnInput.C_q;
        k           = qnInput.k;
        [height, width] = size(C_q);
        
        Q       = qtable(qChoice);
        tempVar = Q.^2 / 12;        % noise variance
        tempAlpha   = sqrt(gamma(3/k)/gamma(1/k)./tempVar);        

        qnStat.Alpha      = repmat(tempAlpha, [height/blockSize, width/blockSize]);
        qnStat.k    = k;
    case 'Mixture'
        qChoice     = qnInput.qChoice;
        blockSize   = qnInput.blockSize;
        nEM         = qnInput.nEM;
        n_qc        = qnInput.n_qc;
        % Initial value of pi_0, sigma2,
        pi_0    = 0.5 * ones(blockSize, blockSize);
        Q       = qtable(qChoice);
        sigma2  = Q.^2/12;        
        for m = 1: nEM;
            z_0  = Estep(n_qc, pi_0, sigma2, qChoice, blockSize);
            [pi_0, sigma2]  = Mstep_train(n_qc, z_0, blockSize);
        end;
        
        qnStat.pi_0 = pi_0;
        qnStat.sigma2   = sigma2;
    otherwise
        error('Unknown quantization noise model');
end;

%%%%%%%%%%%% Standard deviation of Lena in DCT domain
%        113.65       85.999       40.041        21.73       14.571       9.7929       6.6483       5.0498
%        53.402       37.014       24.906       17.367       10.705       7.7974       5.8224       4.3818
%        21.175       21.436       18.847       13.191       9.1706       6.9714       4.7854        3.873
%        11.666       11.546       11.127       9.2682       7.2595       5.3944       4.3128       3.3912
%        6.8702       6.7897       6.6708       6.5803       5.3666       4.2895       3.4351       3.1145
%        4.6043       4.5497       4.5935       4.4159       3.9243       3.3764       3.0659        2.881
%        3.4785       3.4205       3.2558       3.3317       3.1937       2.8983       2.6646       2.5495
%        3.0332       2.9326       2.7749       2.7386       2.7203       2.6458         2.49       2.3875
%%%%%%%%%%%% Variance of Lena in DCT domain
function C_std   = estimate_DCT_variance(iImage, blockSize)
I = double(imread( imageFilename(iImage) ));
C   = blkproc(I , [blockSize blockSize], 'dct2');
[height, width] = size(I);
for u = 1 : blockSize; 
    for v = 1 : blockSize;
        for m = 1 : height/blockSize; 
            for n = 1 : width/blockSize; 
                CUV(m,n) = C((m-1)*blockSize + u, (n-1)*blockSize + v);
            end;
        end;
        C_var(u,v) = var(CUV(:));
    end;
end;
C_std   = sqrt(C_var);
%        C_var = [ 113.65       85.999       40.041        21.73       14.571       9.7929       6.6483       5.0498
%        53.402       37.014       24.906       17.367       10.705       7.7974       5.8224       4.3818
%        21.175       21.436       18.847       13.191       9.1706       6.9714       4.7854        3.873
%        11.666       11.546       11.127       9.2682       7.2595       5.3944       4.3128       3.3912
%        6.8702       6.7897       6.6708       6.5803       5.3666       4.2895       3.4351       3.1145
%        4.6043       4.5497       4.5935       4.4159       3.9243       3.3764       3.0659        2.881
%        3.4785       3.4205       3.2558       3.3317       3.1937       2.8983       2.6646       2.5495
%        3.0332       2.9326       2.7749       2.7386       2.7203       2.6458         2.49       2.3875];
