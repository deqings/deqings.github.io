function [projectedImageNQCS, I_hat] = demo_deblock_foe(iImage, qChoice)
% function demo_deblock_foe(iImage, qChoice, blockSize, lambda)
% DEMO_DEBLOCK_FOE   Image deblocking demo with FoE model.
% calls: code_BDCT.m, imageFilename.m, estimate_qnoise_covariance_matrix.m 
%        deblock_foe.m
% demo program for deblocking by MAP estimation, prior model is FOE
% [Roth2005], noise model is [Stevenson2005] / our proposed estimation
% method
%
% modified from Roth's program by Sun Deqing (Mon, 22 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

% Reference:
% Deqing Sun and Wai-Kuen Cham. "Postprocessing of Low Bit Rate Block DCT
% Coded Images based on a Fields of Experts Prior." IEEE Trans. Image
% Proc., 16(11), pp. 2743- 2751, Nov. 2007.  

% clear;  close all;
addpath('models');
tic;        % added to see the computing time

% iamges 1 -lena 2 peppers 3 barbara 4 baboon, more see imageFilename.m
if nargin <1
    iImage  = 1;      
end;

% quantizer 1-3 : the three quantization tables in the paper
if nargin < 2
    qChoice = 2;
end;

blockSize   = 8;    
model      = foe_5_24();                % parameter setting for deblock_foe  24 5x5 filters
lambda      = 6;        % 6 is OK  
niters      = 200;      % 200 
factorQCS   = 0.5;   factorNQCS  = 0.3; 

I   = double(imread(['Data' filesep imageFilename(iImage)]));
[I_q, C_q]  = code_BDCT(I, qChoice, blockSize);
C   = blkproc(I , [blockSize blockSize], 'dct2');

disp( sprintf('Coded PNSR %2.3fdb', psnr(I, I_q)) );        % for display

qnModel = 'Robertson'; qnInput.qChoice = qChoice; qnInput.blockSize = blockSize   ;
qnStat  = estimate_qnStat(qnModel, qnInput);
I_0    = I_q; % Initial value 

I_hat   = deblock_foe(I_q, model, qnModel, qnStat, blockSize, niters, lambda, I_0, qChoice, I);  % using higher order MRF based on FoE as prior

I_qcs   = project_onto_QCS(I_hat, C_q, qChoice, factorQCS, blockSize);      % projection onto QCS
I_nqcs  = project_onto_QCS(I_hat, C_q, qChoice, factorNQCS, blockSize);     % projection onto NQCS

I_2 = I_nqcs;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OUTPUT
output_PSNR('DISPLAY', I, I_q, I_hat, I_qcs, I_nqcs, iImage);   % display PSNR results

% output_image('DISPLAY', I, I_q, I_hat, I_qcs, I_nqcs, iImage);% display images 
tEnd    = toc;           % added to see the computing time

fprintf('the program takes %3.3f minutes \n', tEnd/60);