function I_hat = deblock_foe(I_q, model, qnModel, qnStat,...
                                          blockSize, niters, lambda, ...
                                          I_0, qChoice, varargin)                         
%
% usage: I_hat = deblock_foe(I_q, p, qnModel, qnStat,...
%                                    blockSize, niters, lambda, delta_t)
% calls: evaluate_foe_log_grad.m, evaluate_data_log_grad.m
%
% deblocks the CODEDIMAGE using an FOE model P. The algorithm assumes
% additive independent quantization noise vector of length BLOCKSIZE^2,
% with zero mean and inverse covariance matrix INVNOISECOVMAT. The
% algorithm performs NITERS iterations with step size DELTAT. 
%
% usage: I_hat = deblock_foe(I_q, p, qnModel, qnStat,...
%                                    blockSize, niters, lambda, delta_t, originalImage) 
% deblocks CODEDIMAGE as before. ORIGINALIMAGE is used for evaluatoin of
% PSNR  for the status messages
%
% 
% Image I_q can either be a gray level image (0 .. 255), or an RGB
% image (0 .. 255 in all channels).
%
%  modified from Roth's program(2005-06-08) by Sun Deqing (22 May 2006)
%  Dept. of EE, Chinese University of Hong Kong
%  contact: dqsun@ee.cuhk.edu.hk
%
%   Author:  Stefan Roth, Department of Computer Science, Brown University
%   Contact: roth@cs.brown.edu
%   $Date: 2005-06-08 18:47:29 -0400 (Wed, 08 Jun 2005) $
%   $Revision: 70 $

% Copyright 2004,2005, Brown University, Providence, RI.
% 
%                         All Rights Reserved
% 
% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a
% commercial product is hereby granted without fee, provided that the
% above copyright notice appear in all copies and that both that
% copyright notice and this permission notice appear in supporting
% documentation, and that the name of Brown University not be used in
% advertising or publicity pertaining to distribution of the software
% without specific, written prior permission.
% 
% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE.  IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR
% ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
% WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
% ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
% OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

  
  % Find appropriate lambda value for given sigma.  The sigma-lambda
  % pairs here are determined experimentally to give good denoising
  % performance with the 5x5 model.
  
                    %TO DO descriptions above after experiment
  
  if (size(I_q, 3) == 3)             % Convert to YCbCr color space if input is RGB
    I_q = 255 * rgb2ycbcr(I_q / 255);
  end

  nPrintTime    = 20;
  prevStepsize = 50;     % seems a better choice and also previous chosen stepsize is OK
  
  C_q = blkproc(I_q, [blockSize blockSize], 'dct2');   % for imposing QCS during iteration
  I_hat = I_0;  
  g = zeros(size(I_hat));
  
  for j = 1:size(I_hat, 3)          % initial value for conjugate gradient
      g(:, :, j) = evaluate_foe_log_grad(model, I_hat(:, :, j));
      g1(:,:,j)  = evaluate_data_log_grad(I_hat(:, :, j), I_q(:, :, j), qnModel, qnStat, blockSize);
  end
  grad      = - (g + lambda * g1);
  grad      = grad / sqrt(grad(:)' * grad(:)); 
  conjGrad  = - grad;
  for i = 1:niters                          % Perform given number of denoising iterations.          
      if ( mod(i, floor(niters/nPrintTime) ) == 0 ||  floor(niters/nPrintTime) == 0 )   % Print out status every 50 iterations
          if  length(varargin) == 1
              I = varargin{1};
              if size(I_q, 3) == 3      
                  tmp = 255 * ycbcr2rgb(I_hat / 255);   % Convert to RGB if necessary
              else
                  tmp = I_hat;
              end
              fprintf('%d/%d iterations (PSNR=%2.3fdB)\n', i, niters, ...
                  psnr(tmp, I));               % PSNR output, if original image is given.  
          else
              fprintf('%d/%d iterations\n', i, niters);    % no use printing to file as above
          end
      end
      
      for j = 1:size(I_hat, 3)
          g(:, :, j) = evaluate_foe_log_grad(model, I_hat(:, :, j));
          g1(:,:,j)  = evaluate_data_log_grad( I_hat(:, :, j), ...
                                               I_q(:, :, j), qnModel, qnStat, blockSize);
      end         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% conjugate gradient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% descent with 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% adaptive step size

      TOL = 0.1;                        % automatic determine the stepsize by line search using steepest descent in [Burden2001] pp. 632-633
      prevGrad       = grad;
      prevConjGrad   = conjGrad;
      
      grad  = - (g + lambda * g1);        
      grad  = grad / sqrt(grad(:)' * grad(:));    
            
      gamma_k    = grad(:)' * ( grad(:) - prevGrad(:) );
      conjGrad   = -grad + gamma_k * prevConjGrad;       
      % needs normalization?
      
      alpha(1)   = 0;                    %linesearch for minima along the nagative gradient direction
      energy(1)  = evaluate_map_energy(I_hat + alpha(1) * conjGrad, I_q,...
                                       qnModel, qnStat, model, blockSize, lambda);
      alpha(3)   = prevStepsize;                   % 1 leads to small stepsize, when the gradient vector is normailized to norm 1
                                                   % 10 seems still small for conjugate gradient, 50
      energy(3)  = evaluate_map_energy(I_hat + alpha(3) * conjGrad, I_q,...
                                       qnModel, qnStat, model, blockSize, lambda);
                            

      while energy(3) >= energy(1)
          alpha(3)  = alpha(3)/2;
          energy(3) = evaluate_map_energy(I_hat + alpha(3) * conjGrad, I_q,...
                                          qnModel, qnStat, model, blockSize, lambda);
          if (alpha(3) < TOL)
              break;
          end;
      end;  

      alpha(2)    = alpha(3)/2;                                     
      energy(2)   = evaluate_map_energy(I_hat + alpha(2) * conjGrad, I_q,...
                                        qnModel, qnStat, model, blockSize, lambda);         
      h(1)    = (energy(2) - energy(1))/alpha(2);
      h(2)    = (energy(3) - energy(2))/( alpha(3)-alpha(2) );
      h(3)    = (h(2) - h(1)) / alpha(3);
      %%% the following assumes h(3) < h(1)?
      alpha(4)  = 0.5 * (alpha(2) - h(1)/h(3));
      energy(4) = evaluate_map_energy(I_hat + alpha(4) * conjGrad, I_q,...
                                      qnModel, qnStat, model, blockSize, lambda);      
      if energy(3) <= energy(4)
          delta   = alpha(3);
      else
          delta   = alpha(4);
      end;               

      I_hat   = I_hat + delta * conjGrad;
      prevStepsize    = delta;              % for next iteration initial value                                       
      if mod(i, floor(niters/nPrintTime) ) == 0  
          factorNQCS  = 0.5; 
          I_hat = project_onto_QCS(I_hat, C_q, qChoice, factorNQCS, blockSize); % Impose QCS during iteration
          I_hat = project_onto_rangeCS(I_hat, 0, 255);                            % Impose RangeCS during iteration
      end;
      %%%%% add to observe energy and PSNR change during iteration
      %%%%% (02/11/2006)
%       if  length(varargin) == 1
%           I = varargin{1};
%           itrEnergy(i) = evaluate_map_energy(I_hat , I_q, qnModel, qnStat, model, blockSize, lambda);   
%           itrPSNR(i)   = psnr(I, I_hat);
%           temp         = project_onto_QCS(I_hat, C_q, qChoice, 0.3, blockSize);
%           itrNQCSPSNR(i)   = psnr(I, temp);
%       end;
  end       % end of iteration loop
       
       
       
  if (size(I_q, 3) == 3)             
      I_hat = 255 * ycbcr2rgb(I_hat / 255);         % Convert back to RGB if necessary
  end
%   if  length(varargin) == 1  
%       save during_iteration itrEnergy itrPSNR itrNQCSPSNR %%%%% add to observe energy and PSNR change during iteration (02/11/2006)
%       plot(itrEnergy);
%       figure; plot(itrPSNR,'*'); hold on; plot(itrNQCSPSNR,'r');
%   end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% fixed stepsize          
% % %    I_hat = I_hat + delta_t * (g + lambda * g1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% steepest descent with 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% adaptive step size        
% %          TOL = 0.1;                        % automatic determine the stepsize by line search using steepest descent in [Burden2001] pp. 632-633
% %          grad  = (g + lambda * g1);        
% %          grad  = grad / sqrt(grad(:)' * grad(:)); 
% %          
% % %          grad  = grad/mean(abs(grad(:)));  % rescale so that the mean of the absolute vector is 1
% % 
% %          alpha(1)   = 0;                    %linesearch for minima along the nagative gradient direction
% %          energy(1)  = evaluate_map_energy(I_hat + alpha(1) * grad, I_q,...
% %                                          qnModel, qnStat, model, blockSize, lambda);
% %          alpha(3)   = 1;            % 1 leads to small stepsize, when the gradient vector is normailized to norm 1
% %          energy(3)  = evaluate_map_energy(I_hat + alpha(3) * grad, I_q,...
% %                                          qnModel, qnStat, model, blockSize, lambda);
% %                                     
% %          while energy(3) >= energy(1)
% %              alpha(3)  = alpha(3)/2;
% %              energy(3) = evaluate_map_energy(I_hat + alpha(3) * grad, I_q,...
% %                                              qnModel, qnStat, model, blockSize, lambda);
% %              if (alpha(3) < TOL)
% %                  break;
% %              end;
% %          end;
% %          
% %         alpha(2)    = alpha(3)/2;                                     
% %         energy(2)   = evaluate_map_energy(I_hat + alpha(2) * grad, I_q,...
% %                                           qnModel, qnStat, model, blockSize, lambda);         
% %         h(1)    = (energy(2) - energy(1))/alpha(2);
% %         h(2)    = (energy(3) - energy(2))/( alpha(3)-alpha(2) );
% %         h(3)    = (h(2) - h(1)) / alpha(3);
% %         %%% the following assumes h(3) < h(1)?
% %         alpha(4)  = 0.5 * (alpha(2) - h(1)/h(3));
% %         energy(4) = evaluate_map_energy(I_hat + alpha(4) * grad, I_q,...
% %                                         qnModel, qnStat, model, blockSize, lambda);      
% %         if energy(3) <= energy(4)
% %             delta   = alpha(3);
% %         else
% %             delta   = alpha(4);
% %         end;       
% %         
% % 
% %         I_hat   = I_hat + delta * grad;
% %         
% %         stepsize(i)     = delta;            % for obervation 
% %         mapEnergy(i) = evaluate_map_energy(I_hat, I_q,...
% %                                            qnModel, qnStat, model, blockSize, lambda);                
