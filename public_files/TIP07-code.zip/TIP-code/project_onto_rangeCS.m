function projectedImage = project_onto_rangeCS(I, lowerValue, upperValue)
%usage: projectedImage = project_onto_rangeCS(I, lowerValue,upperValue)
%calls:
%called by: deblock_foe.m
%
% limits the range of I to [lowerValue, upperValue] and returns the
% result in projectedImage

% modified from Alan Liew's program(18/9/2000) by Sun Deqing (3 June 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

projectedImage = I;
projectedImage( I>upperValue ) = upperValue;
projectedImage( I<lowerValue ) = lowerValue;