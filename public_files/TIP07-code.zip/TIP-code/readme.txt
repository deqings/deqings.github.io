Please run demo_deblock_foe.m

It's slow, please be patient.

MATLAB code for paper
Deqing Sun and Wai-Kuen Cham. "Postprocessing of Low Bit Rate Block DCT Coded Images based on a Fields of Experts Prior." IEEE Trans. Image Proc., 16(11), pp. 2743- 2751, Nov. 2007.

Please read "conditons of use and disclaimer" for proper use of the software.