function data = evaluate_data_log(I_hat, I_q, qnModel, qnStat, blockSize)
%
% calculates log data likelihood term's 
% 
% writtern by Sun Deqing (24/10/2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

switch qnModel
    case {'Robertson',  'ActualVariance'}
        invSigma_q  = qnStat.invSigma_q;
        
        dif = I_q - I_hat;
        [height,width] = size(I_hat);    
        data    = 0;    
        for m = 1:height/blockSize;
            for n = 1:width/blockSize;
                vectorBlock =reshape( dif( (m-1)*blockSize+1 : m*blockSize, ...
                                      (n-1)*blockSize+1  : n*blockSize ), [blockSize*blockSize, 1] );
                data    = data + vectorBlock' * invSigma_q * vectorBlock;
            end;
        end;
        data = - data / 2;
     case {'Truncation', 'Truncation2', 'Truncation3'}
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        temp    = n_qc.^2./qnStat.Var;
        temp(qnStat.CqZero) = 0;        % mask off the truncated coefficients
%         temp(qnStat.CqZero) = temp(qnStat.CqZero)*100;        % to show it's insignificant (06/01/2007)
        data    = -sum(temp(:))/2;    
    case 'Generalized_Gauss'
        k   = qnStat.k;
        Alpha   = qnStat.Alpha;
        
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        temp    = abs(Alpha.*n_qc);
        temp    = temp.^k;
        data    = -sum(temp(:));
        
    case 'Mixture'
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        n_qc2   = n_qc.^2.*(1-qnStat.z_0)/2;
        temp    = blkproc(n_qc2, [blockSize blockSize], 'x./P1', qnStat.sigma2);
        data    = - sum(temp(:));    
    case 'SumMixture'
        sigma2  = qnStat.sigma2;
        pi_0    = qnStat.pi_0;
        
        Q   = qtable(qnStat.qChoice);
        uniProb = pi_0./Q;  % out of QCS? 
        
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');

        n_qc2   = -n_qc.^2/2;
        pi_1    = 1 - pi_0;
        denom   = 1./sqrt(2*pi*sigma2);
        prob    = blkproc(n_qc2, [blockSize blockSize], 'P1.* exp(x./P2).*P3+P4', pi_1, sigma2, denom, uniProb); % prob as sum

        temp    = log(prob);
        data    = sum(temp(:));
        
    otherwise
        error('Unknown quantization noise model');
end;