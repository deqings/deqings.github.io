function [] = output_image(outputChoice, I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
% 
% usage: output_image('DISPLAY', I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
% calls: psnr.m
%
% displays result images
%
% inputs: outputChoice, original image, coded image, projected onto QCS,
% projected onto NQCS
% outputs: display on screen
% 
%
% usage: output_image('SAVE', I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
% calls: 
% 
% saves result images
%
% inputs: outputChoice, original image, coded image, projected onto QCS,
% projected onto NQCS, number index of the image used
% outputs: saved to .bmp files
%
% written by Sun Deqing (Mon, 23 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

switch outputChoice
    case 'DISPLAY'
        figure;
        imshow(uint8(I_q));
        figure; 
        imshow(uint8(I_hat));
        figure; 
        imshow(uint8(projectedImageQCS));
        figure; 
        imshow(uint8(projectedImageNQCS));        
    case 'SAVE'     
        filename    = [imageName(iImage), 'I_q.bmp'];
        imwrite(uint8(I_q), filename);
        filename    = [imageName(iImage), 'I_hat.bmp'];
        imwrite(uint8(I_hat), filename);
        filename    = [imageName(iImage), 'QCSprojectedImage.bmp'];
        imwrite(uint8(projectedImageQCS), filename);
        filename    = [imageName(iImage), 'NQCSprojectedImage.bmp'];
        imwrite(uint8(projectedImageNQCS), filename);
    otherwise
        error('Unknown output choice in output_image');
end