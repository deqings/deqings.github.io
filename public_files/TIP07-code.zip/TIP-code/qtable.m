function y=qtable(qChoice)

% usage: y=qtable(qChoice)
%
% return to y the 8x8 quantization table as specified
% by qChoice.

% modified by : Sun Deqing (22 May 2006)
% if qChoice is a floating point number, it is the scale factor and the
% quantization table is genearted by this scale factor

% written by: Alan Liew (18/9/2000)
% modified by : Sun Deqing (22 May 2006)

if qChoice==1	%0.24b/p for 512x512 Lena		
    y=[050 060 070 070 090 120 255 255;
       060 060 070 096 130 255 255 255;
       070 070 080 120 200 255 255 255;
       070 096 120 145 255 255 255 255;
       090 130 200 255 255 255 255 255;
       120 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255];
 elseif qChoice==2	%0.189b/p for 512x512 Lena
    y=[086 059 054 086 129 216 255 255;
       064 064 075 102 140 255 255 255;
       075 070 086 129 216 255 255 255;
       075 091 118 156 255 255 255 255;
       097 118 199 255 255 255 255 255;
       129 189 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255];
 elseif qChoice==3	%0.15b/p for 512x512 Lena
    y=[110 130 150 192 255 255 255 255;
       130 150 192 255 255 255 255 255;
       150 192 255 255 255 255 255 255;
       192 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255];    
 elseif qChoice==4
    y=[096 066 060 096 144 240 255 255;
       072 072 084 114 156 255 255 255;
       084 078 096 144 240 255 255 255;
       084 102 132 174 255 255 255 255;
       108 132 222 255 255 255 255 255;
       144 210 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255;
       255 255 255 255 255 255 255 255];
 elseif qChoice==5	%0.43b/p for 512x512 Lena
         y=[020 024 028 032 036 080 098 144;
	    024 024 028 034 052 070 128 184;
	    028 028 032 048 074 114 156 190;
	    032 034 048 058 112 128 174 196;
	    036 052 074 112 136 262 206 224;
	    080 070 114 128 162 208 242 200;
	    098 128 156 174 206 242 240 206;
       144 184 190 196 224 200 206 208];  
elseif isa(qChoice, 'float');                       % modified by : Sun Deqing (22 May 2006)
    b_table = [16 11 10 16 24 40 51 61              % for qChoice = 86/16, result a little different from that for qChoice = 3
               12 12 14 19 26 58 60 55 
               14 13 16 24 40 57 69 56 
               14 17 22 29 51 87 80 62 
               18 22 37 56 68 109 103 77 
               24 35 55 64 81 104 113 92 
               49 64 78 87 103 121 120 101 
               72 92 95 98 112 100 103 99];
    y = round( qChoice*b_table );
    y(y>255)  = 255;
    y(y<1)    = 1; 
 end;
 
 %%%%%%%%%%%%%%%%%%%%%% print q table for C program 
% blockSize   = 8; 
% fid = fopen('temp.txt','wt');
% for m = 1 : 5;
%     Q   = qtable(m);
%     for u = 1 : blockSize
%         fprintf(fid, '{');
%         for v = 1 : blockSize
%             fprintf(fid, '%d,', Q(u,v) );
%         end;
%         fprintf(fid, '},');
%         fprintf(fid, '\n');
%     end;
%     fprintf(fid, '\n');
% end;