function projectedImage  = project_onto_QCS(I_hat, C_q, qChoice, factor, blockSize)
%
% usage: projectedImage  = project_onto_QCS(I_hat, coeq, qChoice, factor, blockSize)
% calls: qtable.m                                         
%
% performs projection onto the (narrow) quantization constraint set (N)QCS
% 
% inputs: restored image by certain methods RESTOREDIMAGE; DCT coefficients
% of the coded image QUANTIZEDCOE; quantization method QCHOICE;
% quantizatoin scaling factor FACTOR; block size BLOCKSIZE
% 
% outputs: projected image PROJECTEDIMAGE
%
% FACTOR is the quantization interval scaling. The normal
% quantization constraint uses FACTOR = 0.5. The NQCS proposed
% by S.H. Park & D.S. Kim(IEEE Trans. on IP, vol.8, No.10, 
% Oct 99, pp.1361-1373)
% uses scale <0.5, ie, a good value is FACTOR in [0.2,0.3];
%
% modified from Alan Liew's program (18/9/2000) by Sun Deqing (23 May 2006)
% in Alan's program, the input DCT coefficients are normailized by the
% quantization table

Q = qtable(qChoice);
projectedCoe    = blkproc(I_hat, [blockSize blockSize], 'dct2');        % initial value is DCT coefficients of restored image

maxRange   = factor * Q;         % use blockproc

upper      = blkproc(C_q, [blockSize blockSize], 'x + P1', maxRange);    
lower      = blkproc(C_q, [blockSize blockSize], 'x - P1', maxRange);

projectedCoe( projectedCoe>upper ) = upper( projectedCoe>upper );               % projection onto (N)QCS
projectedCoe( projectedCoe<lower ) = lower( projectedCoe<lower );

projectedImage = blkproc(projectedCoe, [blockSize blockSize], 'idct2');