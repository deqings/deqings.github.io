function g1 = evaluate_data_log_grad(I_hat, I_q, qnModel, qnStat, blockSize)
%
% usage:g = evaluate_data_log_grad(I_hat, I_q,
%                                  qnModel, qnStat, blockSize)
% calls:
%
% calculates log data likelihood term's gradient w.r.t. restored image (or
% original iamge to restore) 
% written by Sun Deqing (Mon, 23 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk
switch qnModel
    case {'Robertson',  'ActualVariance'}
        invSigma_q  = qnStat.invSigma_q;
        
        dif = I_q - I_hat;
        [height,width] = size(I_hat);
        g1  = zeros(size(dif));    
        
        for m = 1:height/blockSize;
            for n = 1:width/blockSize;
                vectorBlock =reshape( dif( (m-1)*blockSize+1 : m*blockSize, ...
                                      (n-1)*blockSize+1  : n*blockSize ), [blockSize*blockSize, 1] );                             
                g1((m-1)*blockSize+1:m*blockSize, (n-1)*blockSize+1:n*blockSize) = reshape( invSigma_q*vectorBlock, [blockSize,blockSize] );
            end;
        end;
    case {'Truncation', 'Truncation2', 'Truncation3'}
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        temp    = n_qc./qnStat.Var;
        temp(qnStat.CqZero) = 0;    % mask off the truncated coefficients
%         temp(qnStat.CqZero) = temp(qnStat.CqZero)*100;        % to show it's insignificant (06/01/2007)
        g1      = blkproc(temp, [blockSize blockSize], 'idct2');
    case 'Generalized_Gauss'
        k   = qnStat.k;
        Alpha   = qnStat.Alpha;
        
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        n_qc    = -n_qc;    % change to I_hat - I_q
        
        temp    = abs(n_qc.^(k-1));
        temp    = temp.*(Alpha.^k)*k;
        temp    = temp.*sign(n_qc);       
        
        g1      = blkproc(temp, [blockSize blockSize], 'idct2');
        g1      = -g1;

    case 'Mixture'
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');
        temp    = n_qc.*(1-qnStat.z_0);
        temp    = blkproc(temp, [blockSize blockSize], 'x./P1', qnStat.sigma2);
        g1      = blkproc(temp, [blockSize blockSize], 'idct2');
    case 'SumMixture'
        sigma2  = qnStat.sigma2;
        pi_0    = qnStat.pi_0;
        
        Q   = qtable(qnStat.qChoice);
        uniProb = pi_0./Q;  % out of QCS? 
        
        n_q     = I_q - I_hat;
        n_qc    = blkproc(n_q, [blockSize blockSize], 'dct2');

        n_qc2   = -n_qc.^2/2;
        pi_1    = 1 - pi_0;
        denom   = 1./sqrt(2*pi*sigma2);

        GauProb = blkproc(n_qc2, [blockSize blockSize], 'P1.* exp(x./P2).*P3', pi_1, sigma2, denom); 
        prob    = blkproc(GauProb, [blockSize blockSize], 'x+P1', uniProb); 
        temp    = blkproc(n_qc, [blockSize blockSize], 'x./P1', sigma2); 
        
        temp    = GauProb.*temp./prob;
        
        g1      = blkproc(temp, [blockSize blockSize], 'idct2');
    otherwise
        error('Unknown quantization noise model');        
end;