function I_0 = compute_foe_ini_value(I_q, model, qnModel, qnStat, blockSize, niters, lambda, ...
                                          stepsize, qChoice, varargin)                         
%
% usage: I_0 = compute_foe_ini_value(I_q, model, qnModel, qnStat, blockSize, niters, lambda, ...
%                                    stepsize, qChoice)
% calls: evaluate_foe_log_grad.m, evaluate_data_log_grad.m
%
% computes initial value for deblock_foe using large stepsize in constant gradient descent 
%
% usage: I_0 = compute_foe_ini_value(I_q, model, qnModel, qnStat, blockSize, niters, lambda, ...
%                                    stepsize, qChoice, originalImage) 
% computes initial value as before. ORIGINALIMAGE is used for evaluatoin of
% PSNR  for the status messages
%
% 
% Image I_q can either be a gray level image (0 .. 255), or an RGB
% image (0 .. 255 in all channels).
%
%  modified from Roth's program(2005-06-08) by Sun Deqing (22 May 2006)
%  Dept. of EE, Chinese University of Hong Kong
%  contact: dqsun@ee.cuhk.edu.hk
%
%   Author:  Stefan Roth, Department of Computer Science, Brown University
%   Contact: roth@cs.brown.edu
%   $Date: 2005-06-08 18:47:29 -0400 (Wed, 08 Jun 2005) $
%   $Revision: 70 $

% Copyright 2004,2005, Brown University, Providence, RI.
% 
%                         All Rights Reserved
% 
% Permission to use, copy, modify, and distribute this software and its
% documentation for any purpose other than its incorporation into a
% commercial product is hereby granted without fee, provided that the
% above copyright notice appear in all copies and that both that
% copyright notice and this permission notice appear in supporting
% documentation, and that the name of Brown University not be used in
% advertising or publicity pertaining to distribution of the software
% without specific, written prior permission.
% 
% BROWN UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
% INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY
% PARTICULAR PURPOSE.  IN NO EVENT SHALL BROWN UNIVERSITY BE LIABLE FOR
% ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
% WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
% ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
% OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

  
  % Find appropriate lambda value for given sigma.  The sigma-lambda
  % pairs here are determined experimentally to give good denoising
  % performance with the 5x5 model.
  
                    %TO DO descriptions above after experiment
  
  if (size(I_q, 3) == 3)             % Convert to YCbCr color space if input is RGB
    I_q = 255 * rgb2ycbcr(I_q / 255);
  end

  nPrintTime    = 10;
  factorNQCS    = 0.5; 
  
  C_q = blkproc(I_q, [blockSize blockSize], 'dct2');   % for imposing QCS during iteration
  I_0 = I_q;  
  g = zeros(size(I_0));
  
  for j = 1:size(I_0, 3)          % initial value for conjugate gradient
      g(:, :, j) = evaluate_foe_log_grad(model, I_0(:, :, j));
      g1(:,:,j)  = evaluate_data_log_grad(I_0(:, :, j), ...
                                          I_q(:, :, j), qnModel, qnStat, blockSize);
  end
  grad      = - (g + lambda * g1);
  grad      = grad / mean(abs(grad(:))); 
  for i = 1:niters                          % Perform given number of denoising iterations.          
      if ( mod(i, floor(niters/nPrintTime) ) == 0 ||  floor(niters/nPrintTime) == 0 )   % Print out status every 50 iterations
          if  length(varargin) == 1
              originalImage = varargin{1};
              if size(I_q, 3) == 3      
                  tmp = 255 * ycbcr2rgb(I_0 / 255);   % Convert to RGB if necessary
              else
                  tmp = I_0;
              end
              fprintf('Initial value %d/%d iterations (PSNR=%2.3fdB)\n', i, niters, ...
                  psnr(tmp, originalImage));               % PSNR output, if original image is given.  
          else
              fprintf('%d/%d iterations\n', i, niters);    % no use printing to file as above
          end
      end
      
      for j = 1:size(I_0, 3)
          g(:, :, j) = evaluate_foe_log_grad(model, I_0(:, :, j));
          g1(:,:,j)  = evaluate_data_log_grad( I_0(:, :, j), ...
                                               I_q(:, :, j), qnModel, qnStat, blockSize);
      end         
      
      grad  = - (g + lambda * g1);  
      grad      = grad / mean(abs(grad(:))); 
      I_0   = I_0 - stepsize * grad;
      if ( mod(i, floor(niters/nPrintTime) ) == 0 ||  floor(niters/nPrintTime) == 0 )      
          I_0 = project_onto_QCS(I_0, C_q, qChoice, factorNQCS, blockSize); % Impose QCS during iteration
          I_0 = project_onto_rangeCS(I_0, 0, 255);                            % Impose RangeCS during iteration
      end;
  end       % end of iteration loop


  if (size(I_q, 3) == 3)             
      I_0 = 255 * ycbcr2rgb(I_0 / 255);         % Convert back to RGB if necessary
  end  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% fixed stepsize          
% % %    I_0 = I_0 + delta_t * (g + lambda * g1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% steepest descent with 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% adaptive step size        
% %          TOL = 0.1;                        % automatic determine the stepsize by line search using steepest descent in [Burden2001] pp. 632-633
% %          grad  = (g + lambda * g1);        
% %          grad  = grad / sqrt(grad(:)' * grad(:)); 
% %          
% % %          grad  = grad/mean(abs(grad(:)));  % rescale so that the mean of the absolute vector is 1
% % 
% %          alpha(1)   = 0;                    %linesearch for minima along the nagative gradient direction
% %          energy(1)  = evaluate_map_energy(I_0 + alpha(1) * grad, I_q,...
% %                                          qnModel, qnStat, model, blockSize, lambda);
% %          alpha(3)   = 1;            % 1 leads to small stepsize, when the gradient vector is normailized to norm 1
% %          energy(3)  = evaluate_map_energy(I_0 + alpha(3) * grad, I_q,...
% %                                          qnModel, qnStat, model, blockSize, lambda);
% %                                     
% %          while energy(3) >= energy(1)
% %              alpha(3)  = alpha(3)/2;
% %              energy(3) = evaluate_map_energy(I_0 + alpha(3) * grad, I_q,...
% %                                              qnModel, qnStat, model, blockSize, lambda);
% %              if (alpha(3) < TOL)
% %                  break;
% %              end;
% %          end;
% %          
% %         alpha(2)    = alpha(3)/2;                                     
% %         energy(2)   = evaluate_map_energy(I_0 + alpha(2) * grad, I_q,...
% %                                           qnModel, qnStat, model, blockSize, lambda);         
% %         h(1)    = (energy(2) - energy(1))/alpha(2);
% %         h(2)    = (energy(3) - energy(2))/( alpha(3)-alpha(2) );
% %         h(3)    = (h(2) - h(1)) / alpha(3);
% %         %%% the following assumes h(3) < h(1)?
% %         alpha(4)  = 0.5 * (alpha(2) - h(1)/h(3));
% %         energy(4) = evaluate_map_energy(I_0 + alpha(4) * grad, I_q,...
% %                                         qnModel, qnStat, model, blockSize, lambda);      
% %         if energy(3) <= energy(4)
% %             delta   = alpha(3);
% %         else
% %             delta   = alpha(4);
% %         end;       
% %         
% % 
% %         I_0   = I_0 + delta * grad;
% %         
% %         stepsize(i)     = delta;            % for obervation 
% %         mapEnergy(i) = evaluate_map_energy(I_0, I_q,...
% %                                            qnModel, qnStat, model, blockSize, lambda);                
