function mapEnergy = evaluate_map_energy(I_hat, I_q, qnModel, qnStat, model, blockSize, lambda)
% 
% usage: mapEnergy = evaluate_map_energy(I_q, ...
%                                                         I_hat, qnModel, qnStat, model, blockSize)
% call: evaluate_foe_log_grad.m, evaluate_foe_log.m, evaluate_data_log.m,
%       evaluate_data_log_grad.m 
% evaluates ergery of the posterori distribution 
% 
% inputs: CODEDIMAGE, RESTOREDIMAGE, INVNOISECOVMAT, MODEL
% outputs: MAPENERGY, MAPENERGYGRAD
%
% written by Sun Deqing (Mon, 23 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

priorEnergy     = evaluate_foe_log(model, I_hat); 

dataEnergy      = evaluate_data_log(I_hat, I_q, qnModel, qnStat, blockSize);
mapEnergy       = - priorEnergy - lambda * dataEnergy;