function observe_noise_model_variance
%
% Observe the difference in variance setting by different noise models
%   1) normalized  so that lambda = 1
%   2) relative ratio between DC noise and AC
%
% Written by Sun Deqing (Mon, 22 Jan 2007)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

% clear;  close all;

%%%%%%%%%%%%%%%%%%%%%%% ActualVariance
lambda  = 1; % near optimal setting
iImage      = 1;    qChoice     = 2;    blockSize   = 8; 
qnModel = 'ActualVariance'; qnInput.qChoice = qChoice; qnInput.blockSize = blockSize; qnInput.iImage = iImage;
qnStat  = estimate_qnStat(qnModel, qnInput);

t   = dctmtx(8);
T   = kron(t,t);
Sigma_qc = T * qnStat.Sigma_q * T' / lambda;         

fid = fopen('observe_noise_variance.txt','wt');
for u = 1 : blockSize
    for v = 1 : blockSize
        fprintf(fid, '%2.3f\t', Sigma_qc((v-1) * blockSize + u ,(v-1) * blockSize + u  ) );
    end;
        fprintf(fid, '\n');
end;
fprintf(fid, '\n');
for u = 1 : blockSize
    for v = 1 : blockSize
        fprintf(fid, '%2.3f\t', Sigma_qc((v-1) * blockSize + u ,(v-1) * blockSize + u  )/ Sigma_qc(1,1) );
    end;
        fprintf(fid, '\n');
end;
fprintf(fid, '\n');
%%%%%%%%%%%%%%%%%%%%%%% Robertson's noise model 
lambda  = 6; % near optimal setting
qnModel = 'Robertson'; qnInput.qChoice = qChoice; qnInput.blockSize = blockSize   ;
qnStat  = estimate_qnStat(qnModel, qnInput);
t   = dctmtx(8);
T   = kron(t,t);
Sigma_qc = T * qnStat.Sigma_q * T' / lambda;         
% fid = fopen('observe_noise_variance.txt','wt');
for u = 1 : blockSize
    for v = 1 : blockSize
        fprintf(fid, '%2.3f\t', Sigma_qc((v-1) * blockSize + u ,(v-1) * blockSize + u  ) );
    end;
        fprintf(fid, '\n');
end;

fprintf(fid, '\n');
for u = 1 : blockSize
    for v = 1 : blockSize
        fprintf(fid, '%2.3f\t', Sigma_qc((v-1) * blockSize + u ,(v-1) * blockSize + u  )/ Sigma_qc(1,1) );
    end;
        fprintf(fid, '\n');
end;


fclose(fid);