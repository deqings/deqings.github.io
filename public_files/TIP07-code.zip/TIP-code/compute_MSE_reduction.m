function rMSE = compute_MSE_reduction(I, I_q, I_hat, blockSize)
%
% compute the MSE reduction for each DCT coefficient 
%

[height, width] = size(I);

N_q = I_q - I;      % MSE of the coded image
N_qc = blkproc(N_q , [blockSize blockSize], 'dct2');
sumMSE  = zeros(blockSize, blockSize);
for m = 1 : height/blockSize;
    for n = 1 : width/blockSize;
        sumMSE  = sumMSE + N_qc( (m-1)*blockSize +1 : m *blockSize, (n-1)*blockSize +1 : n*blockSize ).^2;
    end;
end;
codedMSE  = sumMSE * blockSize.^2 / height / width;

N_hat = I_hat - I;      % MSE of the restored image
N_hatc = blkproc(N_hat , [blockSize blockSize], 'dct2');
sumMSE_hat  = zeros(blockSize, blockSize);
for m = 1 : height/blockSize;
    for n = 1 : width/blockSize;
        sumMSE_hat  = sumMSE_hat + N_hatc( (m-1)*blockSize +1 : m *blockSize, (n-1)*blockSize +1 : n*blockSize ).^2;
    end;
end;
restoredMSE  = sumMSE_hat * blockSize.^2 / height / width;

rMSE    = codedMSE  - restoredMSE;