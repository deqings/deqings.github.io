% function evaluatePSNRgain
%%%
% check the relative MES reduction in each DCT band for different methods

% written by Sun Deqing(20/10/2006)

iImage      = 1;
qChoice     = 2;
blockSize   = 8; 
lambda      = 6;        % 6 is OK  

I   = imread( imageFilename(iImage) );
C   = blkproc(I, [blockSize blockSize], 'dct2');
[I_q, C_q]  = code_BDCT(I, qChoice, blockSize);
I   = double(I);
I_q = double(I_q);

I_hatR  = imread('lenaNQCSprojectedImage.bmp');     %Robertson
I_hatR  = double(I_hatR);
C_hatR   = blkproc(I_hatR, [blockSize blockSize], 'dct2');
% I_hatA  = imread('');     %actual 
% I_hatA  = double(I_hatA);
% C_hatA   = blkproc(I_hatA, [blockSize blockSize], 'dct2');
I_hatW  = imread('Lena_Q2_WGN_FoE.bmp');     %WGN
I_hatW  = double(I_hatW);
C_hatW   = blkproc(I_hatW, [blockSize blockSize], 'dct2');

% Lena_Q2_WGN_FoE_noNQCS.bmp

[height,width]      = size(I);

n_qc    = C_hatR - C;
mse = zeros(blockSize, blockSize);
for u = 1 : blockSize; 
    for v = 1 : blockSize;
        for m = 1 : height/blockSize; 
            for n = 1 : width/blockSize; 
                n_qcUV(m,n) = n_qc((m-1)*blockSize + u, (n-1)*blockSize + v);
            end;
        end;
        mse(u,v)    = var(n_qcUV(:));        
    end;
end;
disp(sprintf('Robertson%f', psnr(I, I_hatR)));
mse

n_qc    = C_hatW - C;
mse1 = zeros(blockSize, blockSize);
for u = 1 : blockSize; 
    for v = 1 : blockSize;
        for m = 1 : height/blockSize; 
            for n = 1 : width/blockSize; 
                n_qcUV(m,n) = n_qc((m-1)*blockSize + u, (n-1)*blockSize + v);
            end;
        end;
        mse1(u,v)    = var(n_qcUV(:));        
    end;
end;
disp(sprintf('Robertson%f', psnr(I, I_hatW)));
mse1

% n_qc    = C_hat - C;
% mse = zeros(blockSize, blockSize);
% for u = 1 : blockSize; 
%     for v = 1 : blockSize;
%         for m = 1 : height/blockSize; 
%             for n = 1 : width/blockSize; 
%                 n_qcUV(m,n) = n_qc((m-1)*blockSize + u, (n-1)*blockSize + v);
%             end;
%         end;
%         mse(u,v)    = var(n_qcUV(:));        
%     end;
% end;
        
        