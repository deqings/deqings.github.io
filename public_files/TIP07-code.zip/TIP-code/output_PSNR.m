function [] = output_PSNR(outputChoice, I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
%
% usage: output_PSNR('DISPLAY', I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
% calls: psnr.m
%
% calculates PSNR for restored image, imposing QCS, imposing NQCS and PSNR
% gain and display the result on MATLAB prompt
%
% inputs: outputChoice, original image, coded image, projected onto QCS,
% projected onto NQCS
% outputs: display on screen
% 
%
% usage: output_PSNR('SAVE', I, I_q, I_hat, projectedImageQCS, projectedImageNQCS, iImage)
% calls: psnr.m
%
% calculates PSNR for restored image, imposing QCS, imposing NQCS and PSNR
% gain and saves the result to the text file
%
% inputs: outputChoice, original image, coded image, projected onto QCS,
% projected onto NQCS, number index of the image used
% outputs: saved to result.txt
%
%
% written by Sun Deqing (Mon, 23 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

rPSNR(1)    = psnr(I, I_q);
rPSNR(2)    = psnr(I, I_hat);
rPSNR(3)    = psnr(I, projectedImageQCS);
rPSNR(4)    = psnr(I, projectedImageNQCS);

switch outputChoice
    case 'DISPLAY'
        disp( ['PSNR results for ', imageName(iImage)] );          
        str = sprintf('%2.3f %2.3f(%2.3f) %2.3f(%2.3f) %2.3f(%2.3f)', rPSNR(1), rPSNR(2), rPSNR(2)-rPSNR(1),...
                      rPSNR(3), rPSNR(3)-rPSNR(1), rPSNR(4), rPSNR(4)-rPSNR(1) );
                  
        disp(['coded ' ' restored ' ' projected-onto-QCS ' ' projected-onto-NQCS']);
        disp(str);        
    case 'SAVE'     % SAVE parameter setting? 
        fid = fopen([imageName(iImage) 'result.txt'] ,'wt');
        str = ['Result for', imageName(iImage)];
        fprintf(fid, str);  
%         fprintf(fid, '\nParameter Setting:\n');        
%         fprintf(fid, 'Quantization parameter %2.3f,  Maximum Itr No. = %d, lambda = %2.3f, GD stepsize %2.3f',...
%             Q_P, niters, lambda, delta_t);
        fprintf(fid,'\nPSNR Result:\n');
        fprintf(fid,'Coded %2.3f\tRes%2.3f Gain %2.3f\n', rPSNR(1), rPSNR(2),rPSNR(2)-rPSNR(1));
        fprintf(fid,'ResQCS%2.3f Gain %2.3f\tResNQCS%2.3f Gain %2.3f\n',...
                rPSNR(3), rPSNR(3)-rPSNR(1), rPSNR(4), rPSNR(4)-rPSNR(1) );
        fprintf(fid, '%2.3f %2.3f(%2.3f) %2.3f(%2.3f) %2.3f(%2.3f)', rPSNR(1), rPSNR(2), rPSNR(2)-rPSNR(1),...
                rPSNR(3), rPSNR(3)-rPSNR(1), rPSNR(4), rPSNR(4)-rPSNR(1) );
        fclose(fid);
    otherwise
        error('Unknown output choice in output_PSNR');
end