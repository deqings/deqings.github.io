function a=quantizer(x,qChoice)

% function: a=quantizer(x,qChoice)
% usage: qimage=blkproc(image,[8,8],'quantizer',3); %qChoice=3
% call: qtable.m
%
% perform quantization on image x using the 8x8 quantization table
% specified by qChoice.
% outputs: the quantized image a

%written by: Alan Liew (18/9/2000)

table=qtable(qChoice);
a=x./table;