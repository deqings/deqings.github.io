function a=dequantizer(x,qChoice)

% function: a=dequantizer(x,qChoice)
% usage: dqimage=blkproc(qimage,[8,8],'dequantizer',3); %qChoice=3
% call: qtable.m
%
% perform dequantization on image x using the quantization table
% specified by qChoice.
% outputs: the dequantized image a

%written by: Alan Liew (18/9/2000)

table=qtable(qChoice);
a=x.*table;