% function determine_optimal_lambda
% simple program to evaluate PSNR gain for different lambda (0-15) and plot
% the curve for different image and quantization table

%
% written by Sun Deqing (Mon, 22 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

clear;  close all;

qChoice     = 1;
blockSize   = 8; 
nImages     = 5; 

nValues     = 10;
recValue    = 6;                            % found experimentally 6 - Robertson 1- actual
ratio       = 2;

p = foe_5_24();                             % parameter setting for deblock_foe  
niters      = 200;  
factorQCS   = 0.5;   factorNQCS  = 0.3; 

qnModel = 'Robertson';
% qnModel = 'ActualVariance'; 
% qnModel = 'Truncation'; 
% qnModel = 'Truncation2'; 

fid = fopen('Lambda_vs_PSNR_Q1.txt','wt'); % need to be changed for differnt quantization table (1-5)

for iImage = 1:nImages;
    
%     fprintf(fid, ['\n' ,imageName(iImage), '\n'] );
   
    I   = double(imread( imageFilename(iImage)));
    [I_q, C_q]  = code_BDCT(I, qChoice, blockSize);
    C   = blkproc(I , [blockSize blockSize], 'dct2');
  
    disp( sprintf('Coded PNSR %2.3fdb', psnr(I, I_q)) );
    
    coded_result_PSNR(iImage) = psnr(I, I_q);
    
    switch qnModel
        case 'Robertson'    
            qnInput.qChoice = qChoice; qnInput.blockSize = blockSize   ;
            qnStat  = estimate_qnStat(qnModel, qnInput);
        case 'ActualVariance'    
            recValue      = 1;        % 1 is OK  
            qnInput.qChoice = qChoice; qnInput.blockSize = blockSize; qnInput.iImage = iImage;
            qnStat  = estimate_qnStat(qnModel, qnInput);
        case {'Truncation', 'Truncation2'}
            qnInput.qChoice     = qChoice; qnInput.blockSize   = blockSize; qnInput.C_q = C_q;
            qnStat  = estimate_qnStat(qnModel, qnInput);
        otherwise
            error('Unknown quantization noise model');
    end;

     for m = 1:nValues; 
        lambda  = ratio^(m - floor(nValues/2)) * recValue; 
        I_0    = I_q;
%         stepsize    = 1;      % fast computation
%         nitersI     = 120;
%         niters      = 40;  
%         I_0 = compute_foe_ini_value(I_q, p, qnModel, qnStat, blockSize, nitersI, lambda, stepsize, qChoice, I);   
                                
        I_hat   = deblock_foe(I_q, p, qnModel, qnStat, blockSize, niters, lambda, I_0, qChoice, I);
        noNQCS_PSNR(iImage, m) = psnr(I, I_hat);                               
        I_qcs   = project_onto_QCS(I_hat, C_q, qChoice, factorQCS, blockSize);     % projection onto QCS
        I_nqcs  = project_onto_QCS(I_hat, C_q, qChoice, factorNQCS, blockSize);    % projection onto NQCS
        
        result_PSNR(iImage, m) = psnr(I, I_nqcs);
        fprintf(fid, '%2.3f\t', result_PSNR(iImage, m));
    end; 
    fprintf(fid, ['NoNQCS\n'] );
    for m = 1:nValues; 
        fprintf(fid, '%2.3f\t', noNQCS_PSNR(iImage, m));
    end;
end;

fclose(fid);


lambda  = [1:nValues]- floor(nValues/2);                 % plot \lambda vs PSNR gain plot
lambda  = ratio.^lambda  * recValue;

marker = {'+', 'o', '*', 's','.'};
for iImage = 1: nImages;
    semilogx(lambda, result_PSNR(iImage,:)- coded_result_PSNR(iImage), ['--',marker{iImage}]);
    hold on;
end;

xlabel('Regularization parameter \lambda');
ylabel('PSNR gain');
title('Regularization parameter \lambda vs PSNR gain');
legend(imageName(1), imageName(2), imageName(3), imageName(4), imageName(5));
% legend(imageName(1+5), imageName(2+5), imageName(3+5), imageName(4+5), imageName(5+5));

% print('-dpsc','-r600', 'Lambda_vs_PSNR_Q2');

%%%%%%%%%%%%%%%%%%% For TIP paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%[Robertson2005]'s model
% lena % ratio 0.5
% 30.570	30.875	31.208	31.398	31.436	31.419	31.397	31.382	31.373	31.368	
% peppers
% 30.671	30.962	31.300	31.523	31.581	31.576	31.563	31.552	31.546	31.544	
% barbara
% 25.956	26.118	26.252	26.324	26.330	26.320	26.307	26.301	26.298	26.293	
% baboon
% 24.343	24.462	24.589	24.652	24.641	24.615	24.594	24.582	24.576 24.572	


% results new
% lena large -> small
% 30.580	30.931	31.271	31.426	31.435	31.405	31.378	31.361	31.351 31.346
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% result
% Robertson's model DC variance * 4
% lena recvalue 6, ratio 1.5
% 31.392	31.405	31.421	31.436	31.455	31.457	31.431	31.351	31.213	31.043	
% before NQCS
% 31.236    31.265  31.305  31.373  31.397  31.429  31.421  31.347  31.211  31.043
% lena
% 31.390	31.401	31.415	31.430	31.440	31.433	31.387	31.278	31.104	30.902	
% NoNQCS
% 31.237	31.266	31.304	31.348	31.391	31.416	31.387	31.282	31.106	30.903	
%%%%%% better than 
%%%%%%%%%%%%%%%%%%%%WGN - 0.5
%%%%%%%%%%%%%%%%%%%%actual variance
% lena ratio 1.5 around 1
% 31.365	31.364	31.364	31.363	31.362	31.354	31.338	31.303
%%%ratio 10 
% lena
% 31.368	31.364	31.363	31.363	31.190	30.336	30.127	30.098	30.095	30.095	
% lena - ratio 0.5
% 30.251	30.476	30.706	30.955	31.190	31.314	31.354	31.363	31.365	31.365	
% peppers
% 30.330	30.564	30.811	31.084	31.305	31.441	31.500	31.522	31.531	31.536	
% barbara
% 25.716	25.770	25.894	26.082	26.208	26.277	26.296	26.298	26.297	26.294	
% baboon
% 24.241	24.320	24.442	24.570	24.625	24.613	24.596	24.584	24.576	24.573	

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%[Robertson2005]'s model
% lena % ratio 0.5
% 30.570	30.875	31.208	31.398	31.436	31.419	31.397	31.382	31.373	31.368	
% peppers
% 30.671	30.962	31.300	31.523	31.581	31.576	31.563	31.552	31.546	31.544	
% barbara
% 25.956	26.118	26.252	26.324	26.330	26.320	26.307	26.301	26.298	26.293	
% baboon
% 24.343	24.462	24.589	24.652	24.641	24.615	24.594	24.582	24.576	24.572	

% 31.342	31.368	31.389	31.406	31.419	31.428	31.435	31.439	31.441	31.440	31.436	31.431	31.425	31.417	31.408	31.398	
% peppers
% 31.545	31.563	31.578	31.589	31.599	31.605	31.610	31.611	31.610	31.607	31.601	31.594	31.585	31.575	31.563	31.549	
% barbara
% 26.276	26.287	26.296	26.304	26.311	26.316	26.320	26.323	26.326	26.327	26.328	26.328	26.327	26.325	26.324	26.321	
% baboon
% 24.559	24.575	24.588	24.600	24.609	24.616	24.623	24.627	24.631	24.634	24.635	24.635	24.635	24.633	24.631	24.629	
%%%%%%%%%%%%% artificially amplify hf noise variance
% lena
%%%%%% factor 0.01

%%%%%% factor 1
% 30.570	30.875	31.208	31.398	31.436	31.419	31.397	31.382	31.373 31.368	
% % 0.01
% 30.500	30.848	31.170	31.353	31.400	31.394	31.382	31.374	31.369 31.366	
% lena --- WGN ratio 0.5
% 31.358	31.375	31.372	31.369	31.366	31.366	31.364	31.365	31.365	31.364	
% peppers
% 31.516	31.537	31.542	31.542	31.542	31.541	31.540	31.541	31.541	31.542	
% barbara
% 26.232	26.270	26.284	26.288	26.291	26.290	26.292	26.291	26.291	26.291	
% baboon
% 24.615	24.602	24.588	24.579	24.573	24.571	24.569	24.569	24.570	24.568	
