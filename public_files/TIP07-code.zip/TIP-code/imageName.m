function y = imageName(n)
% usage: y = imageFilename(n)
%
% return filename of orignal images selected by n
%
% inputs: n 
% outputs: string of the image filename

% written by Sun Deqing (22 May 2006)

name = {'lena', 'peppers', 'barbara', 'baboon', 'foreman', 'flower', 'Model', 'girl', 'hill', 'butter', ...
        'zelda', 'boat', 'plane', 'pens', 'yacht', 'head', 'board', 'airfield', 'couple', 'lax', ...
         'irene', 'man', 'woman', 'fruits'};
y = name{n};   