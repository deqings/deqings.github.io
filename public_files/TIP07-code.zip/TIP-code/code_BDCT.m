function [I_q, C_q]  = code_BDCT(I , qChoice, blockSize)

%usage: [I_q ,C_q]  = code_BDCT(I ,qChoice)
%calls: quantizer.m, dequantizer.m 
%
% perform BLKSIZExBLKSIZE blocked dct compression and decompression using
% the given quantization table q (as specified by qChoice) in quantizer.m. 
%
% inputs: image file, quantization table choice (float point number means
% the scale factor in JPEG), block size (In case other block size may be
% adopted)
% outputs: decompressed image I_q, dequantized coefficients

% modified from Alan Liew's program(18/9/2000) by Sun Deqing (22 May 2006)
% Dept. of EE, Chinese University of Hong Kong
% contact: dqsun@ee.cuhk.edu.hk

I_q  = [];

if(isa(I , 'uint8'))
   I    = double(I );
end;

[height, width] = size(I );
if(mod(height, blockSize)~=0 | mod(width, blockSize) ~= 0)
   error('image dimension must be multiple of block of %d', blockSize);
end;

C       = blkproc(I , [blockSize blockSize], 'dct2');
C_qn    = blkproc(C, [blockSize blockSize], 'quantizer', qChoice);
C_qn    = round(C_qn);
C_q     = blkproc(C_qn, [blockSize blockSize], 'dequantizer', qChoice);

I_q     = blkproc(C_q, [blockSize blockSize], 'idct2');